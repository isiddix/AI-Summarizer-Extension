from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from gpt_summarize import gpt_summarize_request

### The allowed URLs for the API to accept requests from (Restricted for Beta Testing)
origins = [
    "http://localhost",
    "http://localhost:8000",
    "http://localhost:8080",
    ### This allows the testing website to be a valid request
    "https://sarahmorrisonsmith.com",
]

### Initialize the application and make it compliant with Chrome security measures
app = FastAPI()

# Add CORS middleware correctly
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Print a message indicating whether CORS middleware is added
print("CORS middleware added:", CORSMiddleware in app.user_middleware)

### The format of a request payload
class RawText(BaseModel):
    bulleted: bool
    text: str

### One of two endpoints of the API. Will only accept POST requests
@app.post('/')
async def root(request: RawText):
    """Takes in a request payload and summarizes it based on specifications.

    Args:
        request (RawText): The request payload

    Returns:
        JSON: A service payload of the summarized text
    """
    summary = gpt_summarize_request(request.bulleted, request.text)
    return {"summary": summary}
