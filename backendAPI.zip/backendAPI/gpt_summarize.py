# CITE: https://platform.openai.com/docs/overview
# DESC: Showed how to use GPT API and fine tune
from openai import OpenAI

client = OpenAI(api_key="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")

def gpt_summarize_request(bullet_point_format: bool, content_to_summarize: str, temperature: float = 0.75):
    """Summarizes text using GPT 3.5 Turbo in a specified format.

    Args:
      bullet_point_format (bool): Should the summary be bulleted? True for yes; False for no
      content_to_summarize (str): String of text to summarize

    Returns:
      str: Summarized text
    """
    tokens = calculate_max_tokens(content_to_summarize)
    summarize_message = "As a professional summarizer, create a concise and comprehensive summary of the provided text, be it an article, post, conversation, or passage, while adhering to these guidelines: 1. Craft a summary that is detailed, thorough, in-depth, and complex, while maintaining clarity and conciseness. 2. Incorporate main ideas and essential information, eliminating extraneous language and focusing on critical aspects. 3. Rely strictly on the provided text, without including external information (This guidline is extremely important and takes precedence over the other guidelines, especially when dealing with content that is smaller in size and does not have much information to summarize.). 4. Format the summary in "
    completion = None

    # CITE: https://www.w3schools.com/python/ref_string_endswith.asp#:~:text=Check%20if%20the%20string%20ends,.endswith(%22.%22)
    # DESC: Showed how to check if a string ends in punctuation
    # Continues to prompt until the returned content ends in a complete sentence
    while completion is None or not completion.choices[0].message.content.endswith(('.', '!', '?')):
        completion = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant who is amazing at summarizing content in an easily comprenhensible way that is easy to digest, even for those with special needs such as ADHD who find it hard to read large amounts of content at once."},
                {"role": "user", "content": summarize_message + ("bullet point" if bullet_point_format else "paragraph") + " form for easy understanding. 5. All sentences must end in punctuation such as a period, exclamation point, or question mark. Follow the guidelines perfectly to summarize this content: " + content_to_summarize}
            ],
            temperature=temperature,
            max_tokens=tokens
        )

    return completion.choices[0].message.content

def calculate_max_tokens(input_text: str, max_percentage: float = 0.8):
    """Calculates the maximum amount of tokens gpt can use for its output

    Args:
      input_text (str): String of text to split up for tokens
      max_percentage (float): Float value to multiply the max amount of tokens allowed by GPT

    Returns:
      int: Maximum amount of tokens 
    """
    max_allowed_tokens = int(4096 * max_percentage)
    text_tokens = len(client.chat.completions.create(model="gpt-3.5-turbo", messages=[{"role": "user", "content": input_text}]).choices[0].message.content.split())
    max_tokens = min(text_tokens, max_allowed_tokens)

    return max_tokens
