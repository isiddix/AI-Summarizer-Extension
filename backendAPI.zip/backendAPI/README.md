# LeSummari Backend Initialization and Setup

## Overview & Explanation

In this Markdown file is the set of commands necessary to initialize and set up the backend FastAPI for the LeSummari Chrome Extension. Please follow this guide in order and do not skip any steps.

NOTE: The way this guide is set up will make your computer the local host/server of the API. This is because all FastAPI hosting providers charge for the kind of experience we are looking for and we aim to keep this project free.

## Initial Packages and Installation

Run these commands in your command-line IN THIS ORDER to get the necessary packages for operating the API on your local device (which will require you to have the latest version of Python and PIP installed as well, which can be accomplished by this command if necessary `python -m install pip --upgrade`).

* `pip install openai`
* `pip install fastapi`
* `pip install uvicorn`
* `pip install pydantic`

After you have ran these, in the same directory as the "main.py" file (which should be the same directory this file came from), run this command:

`uvicorn main:app --reload`

This will start the API for the extension.

## Troubleshooting

### ERROR: No service found at Port:####

The extension assumes that Uvicorn will run the server on port:8000. If in the console logs for the webpage you are on it states that there is no provider found at port:8000, try running this command to start the API instead:

`uvicorn main:app --host 0.0.0.0`

### ERROR: No response from service

If this is the case, then you may have not waited long enough for the API to be set up and initialized for that run. Cancel that instance of the API and re-run whichever command above you are using to start the API. Wait until a message pops up in the same terminal you executed the command in which says something along the lines of `Application Upload Successful: Awaiting Requests`.

NOTE: This message varies between devices (according to our testing), so use your best judgement to see if a message aligns generally with the message above.

## Limitations

This API will only allow requests from the following origins:

* `https://localhost`
* `http://localhost`
* `https://sarahmorrisonsmith.com`

This is done for beta testing as APIs require lots of security credentials to be active on ANY website and normally are not meant to work with an extension which hops between webpages. This is also done to eliminate a security risk that is posed by making this API public as BlackHat hackers could sniff the API key for OpenAI if this was public (unless we paid for a hosting subscription, but again, we want this to be free).

This means the extension will only work on any webpage from https://sarahmorrisonsmith.com or any local website you are hosting at https://localhost.